<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "as";

// Create connection
$conn = new mysqli($servername, $username,$password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$val = $_GET['temp'];
$val2=(int)$val;
$sql = "INSERT INTO templist(regno) VALUES ('$val2');";

if ($conn->query($sql) === TRUE) {
    echo "Temperature Saved Successfully!";
} else {
    echo "Error:" . $sql . "<br>" . $conn->error;
}


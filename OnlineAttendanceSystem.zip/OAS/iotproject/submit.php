<?php


mysql_connect("localhost","root","");
mysql_select_db("as");


$q1="select * from templist";
$run=mysql_query($q1);
$xyz=1;
while ($row=mysql_fetch_array($run))
{
	$val = $row['regno'];
	$val2=(int)$val;
	$q2="select * from student where roll='$val2'";
	$run2=mysql_query($q2);
	$row2=mysql_fetch_array($run2);
	$d=$row2['dp'];
	$d=$d+2;
	$q3="UPDATE student SET dp=$d where roll='$val2'";
	$run3=mysql_query($q3);
	if ($xyz==1)
	{
		$e=$row2['td'];
		$e=$e+2;
		$q13="UPDATE student SET td=$e";
		$run13=mysql_query($q13);
		$xyz=0;
	}
}


$q4="delete from templist";
$run_post=mysql_query($q4);
echo "<script>alert('Table Emptied')</script>";
echo "<script>window.open('postsubmit.html','_self')</script>";

?>
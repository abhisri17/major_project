<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<title>Attendance</title>

</head>
<body>
		<p><p><p><p>
		<form method="POST" action="abc.php">
			<center>Roll No.:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
			<input type="text" name="type" value="" placeholder=""></center>
            <br><center><input type="submit" name="submit" value="Submit"/></center></br>
		</form>
</body>
</html>
<?php
mysql_connect("localhost","root","");
mysql_select_db("as");
	
	if(isset($_POST['submit'])) 
	{
		$p=$_POST["type"];
		if($p==''  )
		{
			echo "<script>alert('fill in the all field')</script>";
			echo "<script>window.open('abc.php','_self')</script>";
		}
		$q1="select * from templist ";
		$run=mysql_query($q1);
		$x=0;
		$queryx="INSERT INTO templist(regno) VALUES ('$p')";
		$runx=mysql_query($queryx);
		if ($x==0)
		{
			echo "<script>alert('UPDATED')</script>";
			echo "<script>window.open('abc.php','_self')</script>";
		}
			
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<title>Registration</title>

</head>
<body>
		<p><p><p><p>
		<form method="POST" action="abc2.php">
			<center>Roll:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
			<input type="text" name="roll" value="" placeholder=""></center>
			<center>Name:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
			<input type="text" name="name" value="" placeholder=""></center>
			<center>semester:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
			<input type="number" name="sem" value="" placeholder=""></center>
			<center>Branch:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
			<input type="text" name="branch" value="" placeholder=""></center>
			<center>email ID:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
			<input type="text" name="email" value="" placeholder=""></center>
			<center>Create Password:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
			<input type="password" name="pass" value="" placeholder=""></center>
			<center>Retype Password:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
			<input type="password" name="type" value="" placeholder=""></center>
            <br><center><input type="submit" name="submit" value="Submit"/></center></br>
		</form>
</body>
</html>
<?php
mysql_connect("localhost","root","");
mysql_select_db("as");
	
	if(isset($_POST['submit'])) 
	{
		$roll=$_POST["roll"];
		$name=$_POST["name"];
		$sem=$_POST["sem"];
		$branch=$_POST["branch"];
		$email=$_POST["email"];
		$pass=$_POST["pass"];
		$dp=0;
		$td=0;
		
		if($name==''||$sem==''||$branch==''||$email==''||$pass=='')
		{
			echo "<script>alert('fill in the all field')</script>";
			echo "<script>window.open('abc2.php','_self')</script>";
		}
		$q1="select * from templist ";
		$run=mysql_query($q1);
		$x=0;
		$queryx="INSERT INTO student(roll,name,sem,branch,email,pass,dp,td) VALUES ('$roll','$name','$sem','$branch','$email','$pass','$dp','$td')";
		$runx=mysql_query($queryx);
		if ($x==0)
		{
			echo "<script>alert('UPDATED')</script>";
			echo "<script>window.open('abc2.php','_self')</script>";
		}
			
	}
?>